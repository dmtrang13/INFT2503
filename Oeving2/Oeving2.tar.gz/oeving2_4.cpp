#include <iostream>
#include <cstring>
using namespace std;

int main() {
/*
// 4)

    int a = 5;
    int &b;         // 'b' declared as reference but not initialised, requires an initialiser
    int *c;
    c = &b;
    *a = *b + *c;   // invalid type argument of unary, a og b er ikke pointers
    &b = 2;         // lvalue required as left operand of assigment, kan ikke tilordne til en rvalue/adresse (&b)
*/
}